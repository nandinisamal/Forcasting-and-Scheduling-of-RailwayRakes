<?php
session_start();
if (isset($_SESSION['username'])) {
  $user = $_SESSION['username'];
  echo "Welcome, " .$user;
} else {
  // Display message if user is not logged in
  echo "Please log in";
}
?>
<!-- MENU SIDEBAR-->
         <aside class="menu-sidebar d-none d-lg-block">
            <div class="logo">
                <a href="#">
                    <img src="images/icon/logo.png" alt="Cool Admin" />
                </a>
            </div>
            <div class="menu-sidebar__content js-scrollbar1">
                <nav class="navbar-sidebar">
                    <ul class="list-unstyled navbar__list">
                        <li class="active has-sub">
                            <a class="js-arrow" href="#">
                                <i class="far fa-check-square"></i>Coal Rake
							</a>
                            <ul class="list-unstyled navbar__sub-list js-sub-list">
                                <li>
									<a href="import_table.php">
										Import
									</a>
								</li>
								<li>
									<a href="supply_table.php">
										Supply
									</a>
								</li>
							
							</ul>
                        </li>
                      
						<li class="active has-sub">
                            <a class="js-arrow" href="#">
                                <i class="far fa-check-square"></i>Stations
							</a>
                            <ul class="list-unstyled navbar__sub-list js-sub-list">
                                
								<li>
									<a href="station_update.php">
										Manage
									</a>
								</li>
                            </ul>
                        </li>
                        <li class="active has-sub">
                            <a class="js-arrow" href="#">
                                <i class="far fa-check-square"></i>Request
							</a>
                            <ul class="list-unstyled navbar__sub-list js-sub-list">
                                <li>
									<a href="coalrequest_table.php">
										Coal Request
									</a>
								</li>
								
                            </ul>
                        </li>
						  </li>
						       <li class="active has-sub">
                            <a class="js-arrow" href="currentStock.php">
                                <i class="far fa-check-square"></i>Coal Rake stock 
							</a>
                            <ul class="list-unstyled navbar__sub-list js-sub-list">
                                
								
                            </ul>
                        </li>
						      
                    </ul>
                </nav>
            </div>
        </aside>
<!-- END MENU SIDEBAR-->