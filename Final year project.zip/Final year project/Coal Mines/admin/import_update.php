<?php
include('header.php');
?>

<?php
$con=mysqli_connect("localhost","root","","railwayrakes");
$id=$_GET['id'];
if(isset($_POST['btn']))
{

	$date=$_POST['date'];
	$inword=$_POST['inword'];
	$qty=$_POST['qty'];
	
$sql="UPDATE coalrakes SET date='$date',inword='$inword',qty='$qty'WHERE id='$id'";  
if(mysqli_query($con,$sql))
  {
     echo "Data inserted";
  }
  else
  {
     echo "error".mysqli_error($con);
  }
   }

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="au theme template">
    <meta name="author" content="Hau Nguyen">
    <meta name="keywords" content="au theme template">

    <!-- Title Page-->
    <title>Forms</title>
    <!-- Fontfaces CSS-->
    <link href="css/font-face.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-5/css/fontawesome-all.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">

    <!-- Bootstrap CSS-->
    <link href="vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">

    <!-- Vendor CSS-->
    <link href="vendor/animsition/animsition.min.css" rel="stylesheet" media="all">
    <link href="vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet" media="all">
    <link href="vendor/wow/animate.css" rel="stylesheet" media="all">
    <link href="vendor/css-hamburgers/hamburgers.min.css" rel="stylesheet" media="all">
    <link href="vendor/slick/slick.css" rel="stylesheet" media="all">
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="css/theme.css" rel="stylesheet" media="all">

</head>

<body class="animsition">
    <div class="page-wrapper">
        

        
			
        <div class="page-container">
            <!-- HEADER DESKTOP-->
            <?php
	include('headerdesktop.php');
	?>
            <!-- HEADER DESKTOP-->

            <!-- MAIN CONTENT-->
            <div class="main-content">
                <div class="section_content section_content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="card">
                                    <div class="card-header">Coal Rakes</div>
                                    <div class="card-body">
                                        <div class="card-title">
                                            <h3 class="text-center title-2">Coal Rakes Form</h3>
                                        </div>
                                        <hr>
										<?php
										$sql="select *from coalrakes"
										?>
                                        <form action="" method="post" novalidate="novalidate">
                                            <div class="form-group">
                                                <label for="cc-pname" class="control-label mb-1">Date</label>
                                                <input id="cc-pname" name="date" type="date" class="form-control" aria-required="true" aria-invalid="false" value="">
                                            </div>
											<div class="form-group">
                                                <label for="cc-pname" class="control-label mb-1">Inword</label>
                                                <input id="cc-pname" name="inword" type="text" class="form-control" aria-required="true" aria-invalid="false" value="">
                                            </div>
											<div class="form-group">
                                                <label for="cc-pname" class="control-label mb-1">Quantity</label>
                                                <input id="cc-pname" name="qty" type="text" class="form-control" aria-required="true" aria-invalid="false" value="">
                                            </div>
											
                                            
                                            <div>
                                                <button name="btn" id="payment-button" type="submit" class="btn btn-lg btn-info btn-block">
                                                 &nbsp;
                                                    <span id="payment-button-amount">Update</span>  
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            
                    </div>
                </div>
            </div>
        </div>

    </div>

    <!-- Jquery JS-->
    <script src="vendor/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap JS-->
    <script src="vendor/bootstrap-4.1/popper.min.js"></script>
    <script src="vendor/bootstrap-4.1/bootstrap.min.js"></script>
    <!-- Vendor JS       -->
    <script src="vendor/slick/slick.min.js">
    </script>
    <script src="vendor/wow/wow.min.js"></script>
    <script src="vendor/animsition/animsition.min.js"></script>
    <script src="vendor/bootstrap-progressbar/bootstrap-progressbar.min.js">
    </script>
    <script src="vendor/counter-up/jquery.waypoints.min.js"></script>
    <script src="vendor/counter-up/jquery.counterup.min.js">
    </script>
    <script src="vendor/circle-progress/circle-progress.min.js"></script>
    <script src="vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
    <script src="vendor/chartjs/Chart.bundle.min.js"></script>
    <script src="vendor/select2/select2.min.js">
    </script>

    <!-- Main JS-->
    <script src="js/main.js"></script>

</body>

</html>
<!-- end document-->