<?php
include('header.php');
?>
<?php
require('config.php');
?>
<?php
$id=$_GET['id'];
$sql="delete from ordertrack where id=$id";
if(mysqli_query($con,$sql))
{
   header("Location:order_track_table.php");
}
else
{
  echo"error";
}
?>