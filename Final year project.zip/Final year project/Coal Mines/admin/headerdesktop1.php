<!-- HEADER DESKTOP-->

<header class="header-desktop">
                <div class="section_content section_content--p30">
                    <div class="container-fluid">
                        <div class="header-wrap">
                            <form class="form-header" action="" method="POST">
                                            <div class="account-dropdown__footer">
                                                <a href="logout.php">
                                                    <i class="zmdi zmdi-power"></i>Logout</a>
												<h5><?php echo "Welcome to Admin: ".$user; ?></h5>
                                            </div>
										<div>
										
										</div>

											<div class="account-dropdown__footer">
											<?php
											require('config.php');
											if (isset($_SESSION['password'])) {
												$password = $_SESSION['password'];
												$sql = "SELECT * FROM adminuser WHERE id = $password";$result = mysqli_query($con, $sql);
												if ($result && $row = mysqli_fetch_assoc($result)) {
													echo '<i class="zmdi zmdi-power"></i>' . $row['name'];
													}
													}
													?>
                                            </div>
                        </div>
                    </div>
                </div>
            </header>
            <!-- HEADER DESKTOP-->