<?php
include('header.php');
?>
<?php
$con=mysqli_connect("localhost","root","","railwayrakes");
$id=$_POST['id'];
if(isset($_POST['btn']))
{

	$station_id=$_POST['station_id'];
	$qty=$_POST['qty'];
	$order_date=$_POST['order_date'];
	$status=$_POST['status'];
$supply = "SELECT SUM(qty)FROM `order` WHERE station_id ='$station_id'";
$used = "SELECT SUM(rakes_count)FROM usedrakes WHERE station_id ='$station_id'";
$rs = mysqli_query($con,$supply);
$rs1 = mysqli_query($con,$used);
  
if(mysqli_query($con,$sql))
  {
     echo "Data inserted";
  }
  else
  {
     echo "error".mysqli_error($con);
  }
   }

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="au theme template">
    <meta name="author" content="Hau Nguyen">
    <meta name="keywords" content="au theme template">

    <!-- Title Page-->
    <title>Forms</title>
    <!-- Fontfaces CSS-->
    <link href="css/font-face.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-5/css/fontawesome-all.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">

    <!-- Bootstrap CSS-->
    <link href="vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">

    <!-- Vendor CSS-->
    <link href="vendor/animsition/animsition.min.css" rel="stylesheet" media="all">
    <link href="vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet" media="all">
    <link href="vendor/wow/animate.css" rel="stylesheet" media="all">
    <link href="vendor/css-hamburgers/hamburgers.min.css" rel="stylesheet" media="all">
    <link href="vendor/slick/slick.css" rel="stylesheet" media="all">
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="css/theme.css" rel="stylesheet" media="all">

</head>

<body class="animsition">
    <div class="page-wrapper">
        

        
			
        <div class="page-container">
            <!-- HEADER DESKTOP-->
            <?php
	include('headerdesktop.php');
	?>
            <!-- HEADER DESKTOP-->

            <!-- MAIN CONTENT-->
            <div class="main-content">
                <div class="section_content section_content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-6">
                                <table>
									<tr>
										<th>Sr. No.</th>
										<th>Station Name</th>
										<th>Stock</th>
									</tr>
									<?php
										$con = mysqli_connect("localhost","root","","railwayrakes");
										$sql = "select * from station";
										$rs = mysqli_query($con,$sql);
										while($rw = mysqli_fetch_row($rs))
										{
											$supply = "SELECT SUM(qty)FROM `order` WHERE station_id ='$rw[0]'";
											$used = "SELECT SUM(rakes_count)FROM usedrakes WHERE station_id ='$rw[0]'";
											$rs2 = mysqli_query($con,$supply);
											$rs3 = mysqli_query($con,$used);
										
											$rw1 = mysqli_fetch_row($rs2)[0];
											$rw2 = mysqli_fetch_row($rs3)[0];
											$stock = $rw1-$rw2;
											echo "<tr>
												<td>$rw[0]</td>
												<td>$rw[1]</td>
												<td>$stock</td>
											</tr>";
										}
									?>
									
									
									
								</table>
                            </div>
                            
                    </div>
                </div>
            </div>
        </div>

    </div>

    <!-- Jquery JS-->
    <script src="vendor/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap JS-->
    <script src="vendor/bootstrap-4.1/popper.min.js"></script>
    <script src="vendor/bootstrap-4.1/bootstrap.min.js"></script>
    <!-- Vendor JS       -->
    <script src="vendor/slick/slick.min.js">
    </script>
    <script src="vendor/wow/wow.min.js"></script>
    <script src="vendor/animsition/animsition.min.js"></script>
    <script src="vendor/bootstrap-progressbar/bootstrap-progressbar.min.js">
    </script>
    <script src="vendor/counter-up/jquery.waypoints.min.js"></script>
    <script src="vendor/counter-up/jquery.counterup.min.js">
    </script>
    <script src="vendor/circle-progress/circle-progress.min.js"></script>
    <script src="vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
    <script src="vendor/chartjs/Chart.bundle.min.js"></script>
    <script src="vendor/select2/select2.min.js">
    </script>

    <!-- Main JS-->
    <script src="js/main.js"></script>

</body>

</html>
<!-- end document-->