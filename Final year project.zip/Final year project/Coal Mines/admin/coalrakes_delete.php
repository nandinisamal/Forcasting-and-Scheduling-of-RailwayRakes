<?php
$con=mysqli_connect("localhost","root","","railwayrakes");
$id=$_GET['id'];
$sql="delete from coalrakes where id=$id";
if(mysqli_query($con,$sql))
{
   header("Location:coalrakes_table.php");
}
else
{
  echo"error".mysqli_error($con);
}
?>