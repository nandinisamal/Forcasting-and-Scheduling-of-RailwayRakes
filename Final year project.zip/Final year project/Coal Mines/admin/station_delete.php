<?php
require('config.php');
?>
<?php
$id=$_GET['id'];
$sql="DELETE FROM `station` WHERE id = $id ";
if(mysqli_query($con,$sql))
{
   header("Location:station_table.php");
}
else
{
  echo"error".mysqli_error($con);
}
?>