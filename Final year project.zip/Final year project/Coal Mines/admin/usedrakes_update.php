<?php
$con=mysqli_connect("localhost","root","","railwayrakes");
$id=$_GET['id'];
if(isset($_POST['btn']))
{
	$stationid=$_POST['stationid'];
	$rakescount=$_POST['rakescount'];
	$date=$_POST['date'];
	$sql="UPDATE usedrakes SET station_id='$stationid',rakes_count='$rakescount',date='$date' WHERE id='$id'";  
	if(mysqli_query($con,$sql))
	{
		echo "Data inserted";
	}
	else
	{
		echo "error".mysqli_error($con);
	}
}
?>

<?php
include('header.php')
?>
<!-- HEADER DESKTOP-->

            <!-- MAIN CONTENT-->
            <div class="main-content">
                <div class="section_content section_content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="card">
                                    <div class="card-header">Railway Rakes</div>
                                    <div class="card-body">
                                        <div class="card-title">
                                            <h3 class="text-center title-2">Used Rakes</h3>
                                        </div>
                                        <hr>
										<?php
										$sql="select * from station";
										$rq=mysqli_query($con,$sql);
										?>
                                        <form action="" method="post" novalidate="novalidate">
                                            <div class="form-group">
                                                <label for="cc-payment" class="control-label mb-1">Station Id</label>
                                                <select id="cc-pament" name="stationid" type="text" class="form-control" aria-required="true" aria-invalid="false" value="">
												<option>Select Station</option>
												<?php
													while($rw=mysqli_fetch_row($rq))
													{?>
													<option value="<?php echo $rw[0];?>"><?php echo $rw[1];?></option>
													<?php
													}
												?>
												</select>
                                            </div>
                                            <div class="form-group has-success">
                                                <label for="cc-name" class="control-label mb-1">Rakes Count</label>
                                                <input id="cc-name" name="rakescount" type="number" class="form-control cc-name valid" data-val="true" data-val-required="Please enter the name on card"
                                                    autocomplete="cc-name" aria-required="true" aria-invalid="false" aria-describedby="cc-name-error">
                                                <span class="help-block field-validation-valid" data-valmsg-for="cc-name" data-valmsg-replace="true"></span>
                                            </div>
                                          
                                            <div class="form-group has-success">
                                                <label for="cc-name" class="control-label mb-1">Date</label>
                                                <input id="cc-name" name="date" type="date" class="form-control cc-name valid" data-val="true" data-val-required="Please enter the name on card"
                                                    autocomplete="cc-name" aria-required="true" aria-invalid="false" aria-describedby="cc-name-error">
                                                <span class="help-block field-validation-valid" data-valmsg-for="cc-name" data-valmsg-replace="true"></span>
                                            </div>
											<div>
                                                <button id="payment-button" name="btn" type="submit" class="btn btn-lg btn-info btn-block">
                                                   
                                                    <span id="payment-button-amount">Submit</span>
                                                    <span id="payment-button-sending" style="display:none;">Sending…</span>
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                                                    </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <!-- Jquery JS-->
    <script src="vendor/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap JS-->
    <script src="vendor/bootstrap-4.1/popper.min.js"></script>
    <script src="vendor/bootstrap-4.1/bootstrap.min.js"></script>
    <!-- Vendor JS       -->
    <script src="vendor/slick/slick.min.js">
    </script>
    <script src="vendor/wow/wow.min.js"></script>
    <script src="vendor/animsition/animsition.min.js"></script>
    <script src="vendor/bootstrap-progressbar/bootstrap-progressbar.min.js">
    </script>
    <script src="vendor/counter-up/jquery.waypoints.min.js"></script>
    <script src="vendor/counter-up/jquery.counterup.min.js">
    </script>
    <script src="vendor/circle-progress/circle-progress.min.js"></script>
    <script src="vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
    <script src="vendor/chartjs/Chart.bundle.min.js"></script>
    <script src="vendor/select2/select2.min.js">
    </script>

    <!-- Main JS-->
    <script src="js/main.js"></script>

</body>

</html>
<!-- end document-->