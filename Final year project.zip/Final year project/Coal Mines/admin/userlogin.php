<html>
    <head><h1>Login Page</h1>
       <link rel="stylesheet" type="text/css" href="style.css">

    </head>
      <center>
<form action = "userlogin.php" method = "POST">

             Username: <input type="text" name="username"> <br /><br/>
             Password: <input type="password" name="password"> <br /><br/>

            <input type="submit" value="Login" name="submit">


           </form>

      </center>

</body>
</html>

    <?php

       require('connect.php');

       $username = @$_POST['username'];
       $password = @$_POST['password'];

   if(isset($_POST['submit']))
   {
   if($username && $password)
   {
           $check = mysql_query("SELECT * FROM users WHERE username='".$username."' AND password= '".$password."'");
           $rows = mysql_num_rows($check);


         if(mysql_num_rows($check)!=0)
         {
             echo "Successful login.";
         }
         else
         {
            echo "Couldn't find username.";

         }
      }
      else
      {
         echo "Please fill all the fields.";
      }
   }
 ?>

  e-Statistics.htm
         <html>
          <head>
                 <title>e-Statistics</title>
           <style>
           .body{
              margin: 0;

            }

           .nav{
             width: 115%;
             height:40px;
             background:black;
             text-align:center;
           }
          .nav ul{
             width: 800px;
             margin:0 auto;
             padding:0;
             }
            .nav ul li{
               list-style: none;

            }
           .nav ul li a{
               float: left;
               text-decoration:none;
               display:block;
               padding:10px 40px;
               color:#ff9933 ;
               border-right:1px solid #ccc;
             }
            .nav ul li a:hover{
                color:white;

            }
           </style>
      </head>
    <body>

       <div class="nav">
         <ul>
               <li><a href="login.php">Login</a></li>
               <li><a href="">Principal</a></li>
               <li><a href="">Academic Director</a></li>
               <li><a href="">Lecturer</a></li>

         </ul>
       </div>
     </div>
   </div>
 </body>
   </html>