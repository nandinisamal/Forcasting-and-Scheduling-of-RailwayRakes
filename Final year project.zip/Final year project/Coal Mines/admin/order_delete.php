<?php
require('config.php');
?>
<?php
$id=$_GET['id'];
$sql="DELETE FROM `order` WHERE id = $id";
if(mysqli_query($con,$sql))
{
   header("Location:order_table.php");
}
else
{
  echo"error".mysqli_error($con);
}
?>