<?php
	
	$em = $_POST['station_id'];
	//$ps = $_POST['ps'];
	
	$con = mysqli_connect('localhost','root','','railwayrakes');
	
	$sql = "select * from `order` where station_id =".$em;
	
	$rs = mysqli_query($con,$sql);
	echo mysqli_error($con);
	$resp = array();
	
	while($rw = mysqli_fetch_assoc($rs))
	{
		array_push($resp,$rw);
	}
	
	echo json_encode($resp);
	
	exit();
	if($em == "admin@gmail.com" && $ps == "admin")
	{
		$data['status']= 'success';
		$data['msg'] = 'Login success';
		echo json_encode($data);
		
	}
	else{
		$data['status']= 'fail';
		$data['msg'] = 'Login failed';
		echo json_encode($data);
	}

?>