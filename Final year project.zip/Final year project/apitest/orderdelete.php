<?php

$conn = mysqli_connect("localhost","root","","railwayrakes");

$flag = $_POST['flag'];

if($flag == "delete")
{
	
    $id = $_POST['id'];

    
    $sql = "DELETE FROM `order` WHERE id='$id'";

    if(mysqli_query($conn,$sql))
    {
        $data['status'] = 'success';
        $data['msg'] = 'order deleted';
        echo json_encode($data);
    }
    else{
        $data['status'] = 'failed';
        $data['msg'] = 'Order not deleted '.mysqli_error($conn);
        echo json_encode($data);
    }
}

?>
delete_api