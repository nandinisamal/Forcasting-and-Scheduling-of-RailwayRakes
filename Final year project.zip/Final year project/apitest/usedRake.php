<?php

$conn = mysqli_connect("localhost","root","","railwayrakes");

$flag = $_POST['flag'];

if($flag == "insert")
{
	$sid = $_POST['sid'];
	$rakes_count= $_POST['rakes_count'];
	
	$sql = "insert into usedrakes(station_id,rakes_count) values('$sid','$rakes_count')";
	if(mysqli_query($conn,$sql))
	{
		$data['status'] = 'success';
		$data['msg'] = 'inserted sucessfully';
		echo json_encode($data);
	}
	else{
		$data['status'] = 'failed';
		$data['msg'] = 'Order not placed '.mysqli_error($conn);
		echo json_encode($data);
	}
}

?>