<?php

    $flag = $_POST['flag'];
    
    $con = mysqli_connect("localhost", "root", "", "railwayrakes"); 
    if($flag == 'register')
    {
		
		$sname = $_POST['sname'];
        $aname = $_POST['aname'];
        $password = $_POST['ps'];
        $loc = $_POST['loc'];
        $pincode = $_POST['pincode'];
        $seq = $_POST['seq'];
        $sql1 = "INSERT INTO `station` (station_name, admin_name, password, location, pincode, sequence_no) VALUES ('$sname', '$aname', '$password','$loc','$pincode','$seq')";
        if (mysqli_query($con, $sql1)) {
            $data['status'] = 'success';
            $data['msg'] = 'Registration success';
            echo json_encode($data);
        } else {
            $data['status'] = 'fail';
            $data['msg'] = mysqli_error($con);
            echo json_encode($data);
        }
        
        echo json_encode($data);
    }
    else if ($flag == 'login')
    {
        
		$sname = $_POST['sname'];
        $password = $_POST['ps'];
        $sql = "SELECT * FROM `station` WHERE station_name = '$sname' AND password = '$password'";
        $rs = mysqli_query($con, $sql);
        $cnt = mysqli_num_rows($rs);
        if($rs && mysqli_num_rows($rs) > 0) {
            $user_data = mysqli_fetch_assoc($rs);
            $db_sname = $user_data['station_name'];
            $db_password = $user_data['password'];
            
            // Compare passwords
            if($password == $db_password) {
                $data['status'] = 'success';			
                $data['msg'] = 'Login success';
				$data['id'] = $user_data['id'];
            } else {
                $data['status'] = 'fail';
                $data['msg'] = 'Incorrect password';
            }
        } else {
            $data['status'] = 'fail';
            $data['msg'] = 'User not found';
        }
		echo json_encode($data);
    }
?>