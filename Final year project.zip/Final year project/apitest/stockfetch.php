<?php
$con = mysqli_connect("localhost", "root", "", "railwayrakes");
$flag = $_POST['flag'];
if($flag == "stock")
{

 $station_id = $_POST['station_id']; 
 $supply = "SELECT SUM(qty)FROM `order` WHERE station_id ='$station_id'";
$used = "SELECT SUM(rakes_count)FROM `usedrakes` WHERE station_id ='$station_id'";
$rs = mysqli_query($con,$supply);
$rs1 = mysqli_query($con,$used);

if($rs && $rs1){

$rw = mysqli_fetch_row($rs)[0];
$rw1 = mysqli_fetch_row($rs1)[0];

$stock = $rw-$rw1;
$data['stock'] = $stock;
}
echo json_encode($data);
//echo $stock;
mysqli_close($con);
}
?>