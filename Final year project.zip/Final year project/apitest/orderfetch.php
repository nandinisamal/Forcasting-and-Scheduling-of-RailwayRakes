<?php

	$conn = mysqli_connect("localhost", "root", "", "railwayrakes");
	if(mysqli_connect_error()) {
		echo "Failed to connect";
		exit();
	}
	$flag = $_POST['flag'];
	if($flag == "orders")
	{
		$station_id = $_POST['station_id'];
		$query = mysqli_query($conn, "SELECT * FROM `order` where station_id='$station_id'");

		if($query) {
			$resp = array();
			while($row = mysqli_fetch_array($query)) {
			
				array_push($resp,$row);
			}
			echo json_encode($resp);
		}
	}
	mysqli_close($conn);

?>