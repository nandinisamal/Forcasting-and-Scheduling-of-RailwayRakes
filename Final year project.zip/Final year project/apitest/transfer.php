<?php

	$conn = mysqli_connect("localhost", "root", "", "railwayrakes");
	
	$flag = $_POST['flag'];
	
	if($flag == "fetch")
	{
		$id = $_POST['station_id'];
		$sql = "SELECT * from `station` where id = '$id'";
		$rs = mysqli_query($conn,$sql);
		$seq = mysqli_fetch_row($rs)[0];
		$sql1 = "SELECT * from `station` as s JOIN  `order` as o ON s.id = o.station_id where s.id = ".($seq+1)." or s.id = ".($seq-1)." And o.status ='order'";
		//echo $sql1;
		//$rs = mysqli_query($conn,$sql);
		$rs1 = mysqli_query($conn,$sql1);
		$data = array();
		if($rs1){
			//$rw = mysqli_fetch_row($rs)[0];
			while($rw1=mysqli_fetch_assoc($rs1)){
				array_push($data,$rw1);
			//$rw1 = mysqli_fetch_row($rs1)[0];
			//$data = $rw;
			//$data = $rw1;
			}
		}
		echo json_encode($data);
		

		
	}

 if($flag == "transfer"){
	 //$status = $_POST['status'];
	 $id =$_POST['id'];
	$sql2 = "UPDATE `order` SET `status`='transfer' WHERE id ='$id'";
	if(mysqli_query($conn,$sql2))
	{
		$data['status'] = "success";
		$data['msg'] = "Transer success";
		echo json_encode($data);
	}
	else{
		$data['status'] = "failed";
		$data['msg'] = mysqli_error($conn);;
		echo json_encode($data);
	}
 }
?>