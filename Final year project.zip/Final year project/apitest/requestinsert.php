<?php
$conn = mysqli_connect("localhost","root","","railwayrakes");
$flag = $_POST['flag'];
if ($flag == "insert") 
{
    $station_id = $_POST['station_id'];
    $qty = $_POST['qty'];
    $status = 'order';

    $sql = "INSERT INTO `order`( station_id, qty, status) VALUES ('$station_id','$qty','$status')";

    if (mysqli_query($conn, $sql)) {
        $data['status'] = 'success';
        $data['msg'] = 'Order placed';
        echo json_encode($data);
    } else {
        $data['status'] = 'failed';
        $data['msg'] = 'Order not placed: ' . mysqli_error($conn);
        echo json_encode($data);
    }
}
?>