<?php
	$con = mysqli_connect("localhost", "root", "", "railwayrakes");
	//$sql = "SELECT * FROM adminuser WHERE email = '$email'";

	$data = array();

	$flag = $_POST['flag'];
	if($flag == "register") //if (isset($_POST['login'])) 
	{
		$uname = $_POST['uname'];
		$email = $_POST['email'];
		$password = $_POST['ps'];
		$status = 'active';
		$usertype = $_POST['ut'];
		$sql1 = "INSERT INTO adminuser(username,email,password,status,usertype) VALUES('$uname','$email','$password','$status','$usertype')";
		if(mysqli_query($con,$sql1))
		{
			$data['status'] = 'success';
			$data['msg'] = 'Registration success';
			echo json_encode($data);
		}
		else{
			$data['status'] = 'failed';
			$data['msg'] = mysqli_error($con);
			echo json_encode($data);
		}
	}
	else {
		$email = $_POST['email'];
		$ps = $_POST['ps'];
		$sql = "select * from adminuser where email = '".$email."' and password = '".$ps."'";
		$rs = mysqli_query($con,$sql);
		$cnt = mysqli_num_rows($rs);
		if ($cnt>0) {
		  $data['status'] = 'success';
		  $data['msg'] = 'Login success';
		  echo json_encode($data);
		} else {
		  $data['status'] = 'fail';
		  $data['msg'] = 'Login failed';
		  echo json_encode($data);
		}
	}
?>