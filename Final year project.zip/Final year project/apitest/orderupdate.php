<?php

$conn = mysqli_connect("localhost","root","","railwayrakes");

$flag = $_POST['flag'];

if($flag == "update")
{
	$qty = $_POST['qty'];
	$id=$_POST['id'];
	
	$sql = "UPDATE `order` SET qty='$qty' WHERE id='$id'";
	if(mysqli_query($conn,$sql))
	{
		$data['status'] = 'success';
		$data['msg'] = 'order updated';
		echo json_encode($data);
	}
	else{
		$data['status'] = 'failed';
		$data['msg'] = 'Order not updated '.mysqli_error($conn);
		echo json_encode($data);
	}
}

?>