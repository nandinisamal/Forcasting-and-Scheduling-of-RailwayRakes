<?php 

$con = mysqli_connect("localhost", "root", "", "railwayrakes");
   $id = $_POST['id'];     
$sql=mysqli_query($con,"SELECT * FROM `station` WHERE id ='$id'");
while($row = mysqli_fetch_assoc($sql)){
        
		$data = $row;
		
}
echo json_encode($data);
mysqli_close($con);

?>