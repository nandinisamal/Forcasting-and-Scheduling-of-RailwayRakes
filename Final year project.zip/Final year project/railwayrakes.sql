-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 18, 2024 at 03:58 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `railwayrakes`
--

-- --------------------------------------------------------

--
-- Table structure for table `adminuser`
--

CREATE TABLE `adminuser` (
  `id` int(11) NOT NULL,
  `username` text NOT NULL,
  `email` text NOT NULL,
  `password` text NOT NULL,
  `status` text NOT NULL,
  `usertype` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `adminuser`
--

INSERT INTO `adminuser` (`id`, `username`, `email`, `password`, `status`, `usertype`) VALUES
(1, 'admin', 'admin@gmail.com', 'admin', 'progress', 'Admin'),
(2, 'superadmin', 'superadmin@gmail.com', 'superadmin', 'none', 'SuperAdmin'),
(3, 'ABC', 'abc@gmail.co', 'abc@123', 'active', 'super');

-- --------------------------------------------------------

--
-- Table structure for table `coalrakes`
--

CREATE TABLE `coalrakes` (
  `id` int(11) NOT NULL,
  `date` date NOT NULL,
  `inword` text NOT NULL,
  `qty` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `coalrakes`
--

INSERT INTO `coalrakes` (`id`, `date`, `inword`, `qty`) VALUES
(1, '2024-02-08', 'pqr', 89),
(2, '2024-02-16', 'abc', 20),
(5, '2024-02-21', 'asd', 34),
(7, '2024-02-15', 'abc', 20),
(8, '2024-02-01', 'rina', 200);

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE `order` (
  `id` int(11) NOT NULL,
  `station_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `order_date` date NOT NULL DEFAULT current_timestamp(),
  `status` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order`
--

INSERT INTO `order` (`id`, `station_id`, `qty`, `order_date`, `status`) VALUES
(9, 1, 2, '2024-04-11', 'order'),
(10, 1, 15, '2024-04-11', 'order'),
(11, 1, 30, '2024-04-16', 'order'),
(12, 1, 20, '2024-04-16', 'order'),
(13, 1, 20, '2024-04-16', 'order'),
(14, 22, 40, '2024-04-17', 'transfer'),
(15, 1, 0, '2024-04-17', 'order');

-- --------------------------------------------------------

--
-- Table structure for table `ordertrack`
--

CREATE TABLE `ordertrack` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `process` text NOT NULL,
  `process_date` date NOT NULL,
  `process_by` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ordertrack`
--

INSERT INTO `ordertrack` (`id`, `order_id`, `process`, `process_date`, `process_by`) VALUES
(1, 1, 'supplied', '2024-02-15', 'abc');

-- --------------------------------------------------------

--
-- Table structure for table `station`
--

CREATE TABLE `station` (
  `id` int(11) NOT NULL,
  `station_name` text NOT NULL,
  `admin_name` text NOT NULL,
  `password` varchar(255) NOT NULL,
  `location` text NOT NULL,
  `pincode` int(11) NOT NULL,
  `sequence_no` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `station`
--

INSERT INTO `station` (`id`, `station_name`, `admin_name`, `password`, `location`, `pincode`, `sequence_no`) VALUES
(1, 'solapur', 'rohit', '111111', 'pune', 413006, 1),
(22, 'pune', 'Sachin', 'pune1234', 'mumbai', 413002, 2),
(23, 'latur', 'virat', 'latur1', 'solapur', 413004, 3);

-- --------------------------------------------------------

--
-- Table structure for table `usedrakes`
--

CREATE TABLE `usedrakes` (
  `id` int(11) NOT NULL,
  `station_id` int(11) NOT NULL,
  `rakes_count` int(11) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `usedrakes`
--

INSERT INTO `usedrakes` (`id`, `station_id`, `rakes_count`, `date`) VALUES
(1, 6, 20, '2024-02-15'),
(5, 1, 8, '2024-04-13'),
(6, 1, 4, '2024-04-16'),
(7, 22, 15, '2024-04-17'),
(8, 23, 40, '2024-04-17');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adminuser`
--
ALTER TABLE `adminuser`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `coalrakes`
--
ALTER TABLE `coalrakes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ordertrack`
--
ALTER TABLE `ordertrack`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `station`
--
ALTER TABLE `station`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `usedrakes`
--
ALTER TABLE `usedrakes`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `adminuser`
--
ALTER TABLE `adminuser`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `coalrakes`
--
ALTER TABLE `coalrakes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `order`
--
ALTER TABLE `order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `ordertrack`
--
ALTER TABLE `ordertrack`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `station`
--
ALTER TABLE `station`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `usedrakes`
--
ALTER TABLE `usedrakes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
